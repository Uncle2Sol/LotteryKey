# 导入必要的库
import requests  # type: ignore  # pyright: ignore[reportMissingImports]  # 用于在线模式查询区块链API
from time import sleep, time  # 时间相关函数：sleep用于延迟，time用于计时
import os  # 操作系统接口，用于文件路径操作
import threading  # 多线程支持
from concurrent.futures import ThreadPoolExecutor  # 线程池执行器，用于并发执行任务
from multiprocessing import cpu_count  # 获取CPU核心数
import hashlib  # 哈希函数库
import ecdsa  # type: ignore  # 椭圆曲线数字签名算法库
import base58  # type: ignore  # Base58编码库
import secrets  # 安全随机数生成库

# 替代 bit.Key 的兼容类，使用 ecdsa 和 base58 实现
class Key:
    """
    比特币密钥类（替代 bit.Key）
    使用 ecdsa 和 base58 库实现，不依赖 coincurve
    """
    def __init__(self, wif=None):
        """
        初始化密钥
        参数:
            wif: 如果提供，从WIF格式私钥创建；否则生成随机私钥
        """
        if wif:
            # 从WIF格式私钥解码
            decoded = base58.b58decode(wif)
            # 验证校验和
            payload = decoded[:-4]
            checksum = decoded[-4:]
            calculated_checksum = hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]
            if checksum != calculated_checksum:
                raise ValueError("无效的WIF格式：校验和错误")
            # 移除版本字节(0x80)和可能的压缩标志(0x01)
            if len(decoded) == 37 and decoded[33] == 0x01:  # 压缩格式
                self.private_key = decoded[1:33]
            else:  # 未压缩格式
                self.private_key = decoded[1:33]
        else:
            # 生成随机32字节私钥
            self.private_key = secrets.token_bytes(32)
        
        # 创建签名密钥
        self.sk = ecdsa.SigningKey.from_string(self.private_key, curve=ecdsa.SECP256k1)
        self.vk = self.sk.get_verifying_key()
        
        # 生成地址（使用未压缩公钥，兼容旧代码）
        self.address = self._generate_address(compressed=False)
    
    @classmethod
    def from_int(cls, n):
        """
        从整数生成密钥（用于顺序暴力破解）
        参数:
            n: 私钥的整数值
        返回:
            Key对象
        """
        instance = cls.__new__(cls)
        # 将整数转换为32字节的私钥
        instance.private_key = n.to_bytes(32, 'big')
        instance.sk = ecdsa.SigningKey.from_string(instance.private_key, curve=ecdsa.SECP256k1)
        instance.vk = instance.sk.get_verifying_key()
        instance.address = instance._generate_address(compressed=False)
        return instance
    
    def _generate_address(self, compressed=True):
        """
        生成比特币地址
        参数:
            compressed: 是否使用压缩公钥（默认True，但为兼容性使用False）
        返回:
            比特币地址字符串
        """
        # 生成未压缩公钥（0x04 + x + y）
        pubkey = b'\x04' + self.vk.pubkey.point.x().to_bytes(32, 'big') + self.vk.pubkey.point.y().to_bytes(32, 'big')
        
        # SHA256哈希
        sha = hashlib.sha256(pubkey).digest()
        # RIPEMD160哈希
        ripemd = hashlib.new('ripemd160', sha).digest()
        # 添加版本字节（0x00表示主网）
        extended = b'\x00' + ripemd
        # 计算校验和
        checksum = hashlib.sha256(hashlib.sha256(extended).digest()).digest()[:4]
        # Base58编码
        return base58.b58encode(extended + checksum).decode()
    
    def to_wif(self):
        """
        将私钥转换为WIF格式
        返回:
            WIF格式的私钥字符串
        """
        # 版本字节 + 私钥
        extended = b'\x80' + self.private_key
        # 计算校验和
        checksum = hashlib.sha256(hashlib.sha256(extended).digest()).digest()[:4]
        # Base58编码
        return base58.b58encode(extended + checksum).decode()

# 初始化缓存文件：如果不存在则创建，用于保存暴力破解的进度
if os.path.exists(os.getcwd()+"/cache.txt") == False:
    open("cache.txt", "w+")

class Btcbf():
    """
    比特币私钥暴力破解工具类
    警告：此工具仅用于教育和研究目的，实际破解比特币私钥的概率极低（接近零）
    """
    def __init__(self):
        # 初始化计时和计数变量
        self.start_t = 0  # 开始时间戳
        self.prev_n = 0  # 上一次的尝试次数（用于计算速度）
        self.cur_n = 0  # 当前尝试次数
        self.start_n = 0  # 起始尝试编号
        self.end_n = 0  # 结束尝试编号
        self.seq = False  # 是否为顺序模式标志
        self.privateKey = None  # 用户输入的私钥
        self.start_r = 0  # 起始范围值
        
        # 从address.txt文件加载目标地址列表（离线模式使用）
        loaded_addresses = open("address.txt", "r").readlines()
        loaded_addresses = [x.rstrip() for x in loaded_addresses]  # 去除每行的换行符
        # 移除无效的钱包地址（过滤包含'wallet'字符串和空行）
        loaded_addresses = [x for x in loaded_addresses if x.find('wallet') == -1 and len(x) > 0]
        # 转换为集合以提高查找效率（O(1)查找时间）
        self.loaded_addresses = set(loaded_addresses)
        
    def speed(self):
        """
        速度监控函数：在后台线程中持续显示暴力破解的进度和速度
        每2秒更新一次显示信息
        """
        while True:
            if self.cur_n != 0:  # 如果已经开始尝试
                cur_t = time()  # 获取当前时间
                n = self.cur_n  # 当前尝试次数
                if self.prev_n == 0:  # 初始化上一次计数
                    self.prev_n = n
                elapsed_t=cur_t-self.start_t  # 计算已用时间
                # 显示进度信息：当前次数、速度（次/秒）、已用时间、总尝试次数
                print("当前次数: "+str(n)+", 当前速度: "+str(abs(n-self.prev_n)//2)+"/秒"+f", 已用时间: [{str(elapsed_t//3600)[:-2]}:{str(elapsed_t//60%60)[:-2]}:{int(elapsed_t%60)}], 总计: {n-self.start_r} ", end="\r")
                self.prev_n = n  # 更新上一次计数
                if self.seq:  # 如果是顺序模式，保存进度到缓存文件
                    open("cache.txt","w").write(f"{self.cur_n}-{self.start_r}-{self.end_n}")
            sleep(2)  # 每2秒更新一次
        
    def random_brute(self, n):
        """
        随机暴力破解函数（离线模式）
        生成随机私钥，检查其对应的地址是否在目标地址列表中
        
        参数:
            n: 当前尝试次数（用于更新进度）
        """
        self.cur_n=n  # 更新当前尝试次数
        key = Key()  # 生成随机比特币密钥对
        # 检查生成的地址是否在目标地址列表中
        if key.address in self.loaded_addresses:
                print("🎉 找到匹配地址！！")  # 找到匹配地址
                print("公钥地址: "+key.address)  # 显示公钥地址
                print("私钥: "+key.to_wif())  # 显示私钥（WIF格式）
                # 将找到的地址和私钥保存到foundkey.txt文件
                f = open("foundkey.txt", "a")  # 追加模式打开文件
                f.write(key.address+"\n")  # 写入地址
                f.write(key.to_wif()+"\n")  # 写入私钥
                f.close()
                sleep(510)  # 等待510秒后退出
                exit()  # 退出程序
            
    def sequential_brute(self, n):
        """
        顺序暴力破解函数（离线模式）
        从整数n生成对应的私钥，按顺序尝试所有可能的私钥
        
        参数:
            n: 私钥的整数值（从0开始递增）
        """
        self.cur_n=n  # 更新当前尝试次数
        key = Key().from_int(n)  # 从整数n生成对应的私钥（顺序模式）
        # 检查生成的地址是否在目标地址列表中
        if key.address in self.loaded_addresses:
            print("🎉 找到匹配地址！！")  # 找到匹配地址
            print("公钥地址: "+key.address)  # 显示公钥地址
            print("私钥: "+key.to_wif())  # 显示私钥（WIF格式）
            # 将找到的地址和私钥保存到foundkey.txt文件
            f = open("foundkey.txt", "a")  # 追加模式打开文件
            f.write(key.address+"\n")  # 写入地址
            f.write(key.to_wif()+"\n")  # 写入私钥
            f.close()
            sleep(500)  # 等待500秒后退出
            exit()  # 退出程序
    
    
    def random_online_brute(self, n):
        """
        随机在线暴力破解函数（在线模式）
        生成随机私钥，通过区块链API查询地址是否有余额
        
        参数:
            n: 当前尝试次数（用于更新进度）
        
        警告：此函数会频繁访问外部API，可能被限流或封禁IP
        """
        self.cur_n = n  # 更新当前尝试次数
        key = Key()  # 生成随机比特币密钥对
        # 通过blockchain.info API查询该地址是否收到过比特币
        # 注意：频繁请求可能导致IP被封禁
        the_page = requests.get("https://blockchain.info/q/getreceivedbyaddress/"+key.address+"/").text
        if int(the_page)>0:  # 如果地址收到过比特币（余额大于0）
            print(the_page)  # 显示收到的比特币数量
            print("🎉 找到活跃地址！！")  # 找到活跃地址
            print("公钥地址: "+key.address)  # 显示公钥地址
            print("私钥: "+key.to_wif())  # 显示私钥（WIF格式）
            # 将找到的地址和私钥保存到foundkey.txt文件
            f = open("foundkey.txt", "a")  # 追加模式打开文件
            f.write(key.address+"\n")  # 写入地址
            f.write(key.to_wif()+"\n")  # 写入私钥
            f.close()
            sleep(500)  # 等待500秒后退出
            exit()  # 退出程序
            
            
    def num_of_cores(self):
        """
        获取用户指定的CPU核心数
        用于控制线程池的大小，影响暴力破解的并发度
        
        返回:
            self.cores: 要使用的CPU核心数
        """
        available_cores = cpu_count()  # 获取系统可用的CPU核心数
        # 提示用户输入要使用的核心数
        cores = input(f"\n可用CPU核心数: {available_cores}\n \n要使用多少个核心？(直接回车使用全部核心) \n \n请输入>")
        if cores == "":  # 如果用户直接回车，使用所有可用核心
            self.cores = int(available_cores)
        elif cores.isdigit():  # 如果输入是数字
            cores = int(cores)
            if 0 < cores <= available_cores:  # 核心数在有效范围内
                self.cores = cores
            elif cores<=0 :  # 核心数无效（负数或0）
                print(f"错误！不能使用 {cores} 个CPU核心！！")
                input("按回车键退出")
                raise ValueError("negative number!")
            elif cores > available_cores:  # 核心数超过可用数，询问用户确认
                print(f"\n 您只有 {available_cores} 个核心")
                print(f" 确定要使用 {cores} 个核心吗？")
                core_input = input("\n[y]是 或 [n]否>")
                if core_input == "y":  # 用户确认
                    self.cores = cores
                else:  # 用户取消，使用所有可用核心
                    print("使用所有可用核心")
                    self.cores = available_cores
        else:  # 输入格式错误
            print("输入错误！")
            input("按回车键退出")
            exit()
            
    def generate_random_address(self):
        """
        生成随机比特币地址和私钥
        用于创建新的比特币钱包
        """
        key = Key()  # 生成随机密钥对
        print("\n 公钥地址: "+key.address)  # 显示公钥地址
        print(" 私钥: "+key.to_wif())  # 显示私钥（WIF格式）
    
    def generate_address_fromKey(self):
        """
        从用户输入的私钥生成对应的公钥地址
        用于验证私钥或恢复钱包
        """
        if self.privateKey != "":  # 如果用户输入了私钥
            key = Key(self.privateKey)  # 从私钥创建密钥对象
            print("\n 公钥地址: "+key.address)  # 显示对应的公钥地址
            print("\n 您的钱包已就绪！")  # 提示钱包已就绪
        else:  # 如果没有输入私钥
            print("未输入私钥")  # 提示无输入
            
    def get_user_input(self):
        """
        主菜单函数：获取用户输入并执行相应操作
        提供5个选项：生成随机密钥对、从私钥生成地址、离线暴力破解、在线暴力破解、退出
        """
        # 显示主菜单并获取用户选择
        user_input = input("\n 请选择要执行的操作： \n \n   [1]: 生成随机密钥对 \n   [2]: 从私钥生成公钥地址 \n   [3]: 离线模式暴力破解比特币 \n   [4]: 在线模式暴力破解比特币 \n   [0]: 退出程序 \n \n 请输入>")
        
        if user_input == "1":  # 选项1：生成随机密钥对
            self.generate_random_address()
            print("\n 您的钱包已就绪！")
            input("\n 按回车键退出")
            exit()
            
        elif user_input == "2":  # 选项2：从私钥生成地址
            self.privateKey = input("\n 请输入私钥>")  # 获取用户输入的私钥
            try:
                self.generate_address_fromKey()  # 尝试生成地址
            except:  # 如果私钥格式错误
                print("\n 私钥格式错误")
            input("按回车键退出")
            exit()
            
        elif user_input == "3":  # 选项3：离线暴力破解模式
            # 选择攻击方式：随机或顺序
            method_input = input(" \n 请选择攻击方式： \n \n   [1]: 随机攻击 \n   [2]: 顺序攻击 \n   [0]: 退出 \n \n 请输入>")
            if method_input=="1":  # 随机攻击
                target = self.random_brute  # 设置目标函数
            elif method_input=="2":  # 顺序攻击
                # 检查是否有缓存的进度（可以恢复之前的破解）
                if open("cache.txt", "r").read() != "":
                    r0=open("cache.txt").read().split("-")  # 读取缓存的范围
                    print(f"恢复范围 {r0[0]}-{r0[2]}")  # 显示要恢复的范围
                    # 使用线程池执行顺序暴力破解
                    with ThreadPoolExecutor(max_workers=self.num_of_cores()) as pool:
                        print("\n正在恢复...\n")
                        self.start_t = time()  # 记录开始时间
                        self.start_r = int(r0[1])  # 起始范围
                        self.start_n = int(r0[0])  # 起始编号
                        self.end_n = int(r0[2])  # 结束编号
                        self.seq=True  # 设置为顺序模式
                        # 提交所有任务到线程池
                        for i in range(self.start_n,self.end_n):
                            pool.submit(self.sequential_brute, i)
                        print("正在停止...\n")
                        exit()
                else:  # 没有缓存，开始新的破解
                    range0 = input("\n 请输入范围（十进制，例如：1-100）>")  # 获取用户输入的范围
                    r0 = range0.split("-")  # 分割范围字符串
                    r0.insert(1,r0[0])  # 插入起始值作为start_r
                    open("cache.txt", "w").write("-".join(r0))  # 保存范围到缓存文件
                    # 使用线程池执行顺序暴力破解
                    with ThreadPoolExecutor(max_workers=self.num_of_cores()) as pool:
                        print("\n 正在启动...")
                        self.start_t = time()  # 记录开始时间
                        self.start_r = int(r0[1])  # 起始范围
                        self.start_n = int(r0[0])  # 起始编号
                        self.end_n = int(r0[2])  # 结束编号
                        self.seq=True  # 设置为顺序模式
                        # 提交所有任务到线程池
                        for i in range(self.start_n,self.end_n):
                            pool.submit(self.sequential_brute, i)
                        print("正在停止...\n")
                        exit()
            else:  # 用户选择退出
                print("正在退出...")
                exit()
                
        elif user_input == "4":  # 选项4：在线暴力破解模式
            # 选择攻击方式：随机或顺序
            method_input = input(" \n 请选择攻击方式： \n \n   [1]: 随机攻击 \n   [2]: 顺序攻击 \n   [0]: 退出 \n \n 请输入>")
            if method_input=="1":  # 随机在线攻击
                # 使用线程池执行随机在线暴力破解
                with ThreadPoolExecutor(max_workers=self.num_of_cores()) as pool:
                    r = range(100000000000000000)  # 设置一个很大的范围
                    print("\n 正在启动...")
                    self.start_t = time()  # 记录开始时间
                    self.start_n = 0
                    # 提交任务到线程池，每次提交后延迟0.1秒（避免API请求过快）
                    for i in r:
                        pool.submit(self.random_online_brute, i)
                        sleep(0.1)  # 延迟以避免API限流
                    print("正在停止...\n")
                    exit()
            elif method_input=="2":  # 顺序在线攻击（尚未实现）
                print("顺序在线攻击功能即将推出！")
                input("按回车键退出")
                exit()
            else:  # 用户选择退出
                print("正在退出...")
                exit()
                
        elif user_input == "0":  # 选项0：退出程序
            print("正在退出...")
            sleep(2)
            exit()
        else:  # 无效输入，默认执行选项1
            print("未输入，自动选择选项 [1]")
            self.generate_random_address()
            print("您的钱包已就绪！")
            input("按回车键退出")
            exit()
            
        # 如果选择了随机攻击（选项3的随机模式），执行以下代码
        with ThreadPoolExecutor(max_workers=self.num_of_cores()) as pool:
            r = range(100000000000000000)  # 设置一个很大的范围
            print("\n 正在启动...")
            self.start_t = time()  # 记录开始时间
            self.start_n = 0
            # 提交任务到线程池
            for i in r:
                pool.submit(target, i)
            print("正在停止...\n")
            exit()



if __name__ =="__main__":
    """
    程序入口点
    创建Btcbf对象，启动两个线程：
    1. 主线程：处理用户输入和暴力破解逻辑
    2. 监控线程：显示进度和速度信息
    """
    obj = Btcbf()  # 创建Btcbf对象
    try:
        # 创建两个线程
        t0 = threading.Thread(target=obj.get_user_input)  # 主线程：处理用户输入
        t1 = threading.Thread(target=obj.speed)  # 监控线程：显示进度
        t1.daemon = True  # 设置为守护线程（主程序退出时自动退出）
        t0.daemon = True  # 设置为守护线程
        t0.start()  # 启动主线程
        t1.start()  # 启动监控线程
        # 保持程序运行（两个sleep总计约92天，实际通过Ctrl+C或找到密钥时退出）
        sleep(4000000)  # 保持程序在try..except块中运行
        sleep(4000000)  # 保持程序在try..except块中运行
    except KeyboardInterrupt:  # 捕获Ctrl+C中断信号
        print("\n\n检测到 Ctrl+C 按键。\n正在退出...")
        exit()
    else:  # 捕获其他异常
        print(f"\n\n错误: {Exception.args}\n")
        exit()
            
    
